#include <iostream>
#include<cstdlib>

using namespace std;
int main ()

{
    
cout<<"\t\t\tBienvenidos a mi tienda de zapatos\n";

char disp,A,B,C,tipo;
char ref[30],desc[30];
int talla,cant;
float costo,precio,pu; 
cout<<"\n ADMINISTRAR VENTA DE ZAPATOS";
cout<<"\n Digite la referencia del zapato....."<<endl;
cin.getline(ref,sizeof(ref));// PARA QUE TENGA EN CUENTA LOS ESPACIOS AL DIGITAR LA REFERENCIA
cout<<"\n Digite la descripcion del zapato....."<<endl; //PARA QUE TENGA EN CUENTA LOS ESPACIOS AL DIGITAR LA DESCRIPCION
cin.getline(desc,sizeof(desc));
cout <<"Digita la talla"<<endl;
cin>> talla;
cout <<"Digita la letra si esta o no disponoble para la venta S/N"<<endl;
cin>> disp;
cout<<" Digite la cantidad de zapatos: "<<endl;
cin>> cant;
cout<<"Digita el costo del zapata"<<endl;
if(disp=='S')
{

cin>>costo;//De la linea 26 al 53 con if anidados se determina el tipo, % de utilidad yel precio de venta
if (costo<=30000)
{
	tipo='A';
	pu=50;
	precio=costo+costo*pu/100;
}
else
{

 if (costo>30000&&costo<=60000)
    { 
	tipo='B';
	pu=40;
	precio=costo+costo*pu/100;	    
    }

    else 
    {
	
	  if(costo>60000)     	
        {
         tipo='C';
	     pu=30;
        precio=costo+costo*pu/100;
        }
   }
}

 //cout<<"\n Digite precio unidad del zapato......";  
//cin>>precio;

cout<<"\n LOS DATOS REGISTRADOS SON LOS SIGUIENTES:";
cout<<"\n REFERENCIA:"<<ref;
cout<<"\n TIPO:"<<tipo;
cout<<"\n DESCRIPCION:"<<desc;
cout<<"\n TALLA:"<<talla;
cout<<"\n DISPONIBLE:  "<<disp;
cout<<"\n CANTIDAD DE ZAPATOS:"<<cant;
cout<<"\n COSTO UNIDAD:"<<costo;
cout<<"\n COSTO TOTAL:"<<cant*costo;  //COSTO TOTAL DE COMPRA DE LOS ZAPATOS
cout<<"\n PRECIO UNIDAD:"<<precio;
cout<<"\n PRECIO TOTAL DE  "<<cant<<" UNIDADES: "<<cant*precio;//PRECIO TOTAL VENTA DE ZAPATOS
cout<<"\n UTILIDAD P0R UNIDAD:  "<<precio-costo;
cout<<"\n UTILIDAD TOTAL:"<<cant*(precio-costo);
cout<<"\n PORCENTAJE DE UTILIDAD :"<<pu<<"%";
cout<<"\n";
}
if(disp=='N')
{
cout<<"\n NO HAY DISPONIBILIDAD DE ESTOS ZAPATOS";
}

if(disp!='S'&&disp!='N')
{
cout<<"\n!!!!! ERROR EN LA ENTRADA DE DATOS";	//Si digita en disponibilidad un valor diferente a S/N, muestra en pantalla error de entrada de datos
}


cout<<"\n";
cout<<" GRACIAS POR DIGITAR LA INFORMACIÓN \n \n";


cout<<"\t\t\t Realizado por Valentina Atehortúa Zapata\n";
return 0;
}